<template>
<div id="work-header">
  <div class="work-header">
    <div class="work-header__img-container">
      <img class="work-header__img" src="https://i.ibb.co/j3bWP19/work-header.png" alt="work header image">
    </div>
    <span v-scrollanimation class="work-header__title">Work</span>
    <div class="c-padding">
      <button class="button">View case</button>
    </div>
  </div>
</div>
</template>

<script>
export default {

}
</script>

<style lang="scss">
@import "@/assets/styles/_work-header.scss";
</style>
