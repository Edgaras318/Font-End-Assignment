<template>
<div id="home">
  <h1>This is Home page still emmpty :/ Try work page please!</h1>
</div>
</template>

<script>
export default {
  name: 'Home'
}
</script>

<style lang="scss" scoped>

</style>
